#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "user.h"
#include "account.h"
#include "transaction.h"

void add_transaction(t_user* user, char *IBAN, int amount, char *type, char *description)
{

}