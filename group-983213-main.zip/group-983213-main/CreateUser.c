#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "user.h"

t_user *create_user(char *nom, char* email)
 {
    t_user *user = malloc(sizeof(t_user));
    
    user->_nom = nom;
    user->_email = email;
    user->_qtyA = 0;

    printf("user created\n");
    return (user);
 }


void display_user(t_user *user){
    printf("%s %s %d\n",user->_nom, user->_email, user->_qtyA);
}



void clear_user(t_user *user) {
    free(user);
    printf("malloc free\n");
}

