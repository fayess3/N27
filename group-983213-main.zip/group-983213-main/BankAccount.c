#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "user.h"
#include "account.h"

t_account *create_account()
{
    t_account *account = malloc(sizeof(t_account));

int i;
 
   srand(time(NULL));
    for(i='a';i<'b';i++){
    printf("Your IBAN is : \n");
    printf("FR%d ",rand()%99);
    }
    for(i='a'; i<'g';i++)
    {
    printf("%3d ", rand()%10000);
    }
    printf("\n");

    account->_IBAN = 0;
    account->_qtyA = 0;

    printf("account created\n");
    
    // printf("%d\n",account->_IBAN);
    
   return(account);
 }


void display_account(t_user *user){
    printf("the account is ");
    printf("%d \n",user->_qtyA);
}



void clear_accounts(t_user *user) {
    free(user);
    printf("malloc free\n");
}

