#ifndef ACCOUNT
#define ACCOUNT


typedef struct s_account
 {
            int _IBAN;
            int _qtyA;
}t_account;

// create_account();
t_account *create_account();
// void display_accounts(t_user *user);
void clear_accounts(t_user *user);
#endif