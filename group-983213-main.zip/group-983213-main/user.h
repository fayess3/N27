#ifndef USER
#define USER

typedef struct  s_user
 {
            char *_nom;
            char *_email;
            int _qtyA;
            // int *_tableau[];
}               t_user;

// typedef struct s_account
//  {
//             char *_IBAN;
//             int _qtyA;
// }               t_account;


t_user *create_user(char *nom, char* email);
void display_user(t_user *user);
void clear_user(t_user *user);
int deposit(t_user *user, int amount);
int withdraw(t_user *user, int amount);
void display_account(t_user *user);
void clear_accounts(t_user *user);

// int deposit(t_user *user, int amount);

#endif