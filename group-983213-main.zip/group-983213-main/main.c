#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "user.h"
#include "account.h"


    int main()
    {
        t_user *user = create_user("Faye", "Faye.Sarah@etna.io");
        
        display_user(user);

        clear_user(user);
        deposit(user, 340);
        withdraw(user, 200);
        create_account();
        display_account(user);
        // clear_accounts(user);
        return (0);
    }