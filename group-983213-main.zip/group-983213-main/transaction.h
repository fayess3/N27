#ifndef TRANSACTION_H
#define TRANSACTION_H


 typedef struct s_transaction
 {
            int *_qty;
            int _qtyA;
            char _typeT;
            char _descrip;

}          t_transaction;   


 typedef struct s_list
 {
            int *_qty;
            int _qtyA;
            char _typeT;
            char _descrip;

}          t_list;  


void add_transaction(t_user* user, char *IBAN, int amount, char *type, char *description);
#endif