# Groupe de faye_s 983213

<h3 align="center"><em>N27</em> </h3>



<!-- ABOUT THE PROJECT -->
## A Propos du Projet

Ce projet scolaire délivré par l'ETNA () vise à nous former sur les basics du c  avec des exercicies.


## Étape 1 : Utilisateur

- J'ai cree une structure s_user pour stocker les données de vos clients. Cette structure  contien un nom, une adresse email et une quantité d'argent déposée.
- J'ai definis le type t_user à partir de cette structure.

- J'ai une fonction create_user elle a crée un utilisateur en remplissant la structure et retourner un pointeur vers elle.
L'argent de l'utilisateur doit etre à 0.

- une fonction display_user qui affiche des donne de l'utilisateur.

- une fonction clear_user cette fonction doit free l'instance de la structure.

## Etape 2

- J'ai fait fonction  deposite qui doit ajouter à l'utilisateur la quantité d'argent passée en paramètre.
Elle retourne 0 si la transaction se passe bien, 1 dans le cas contraire. 

- J'ai une fonction withdraw basée sur le prototype ci-dessus.

Cette fonction doit retirer à l'utilisateur la quantité d'argent passée en paramètre.

Elle retourne 0 si la transaction se passe bien, 1 dans le cas contraire.
## Etape 3

- J'ai cree une structure s_account. Cette structure devra une quantité d'argent déposée et un IBAN.

Définissez le type t_account à partir de cette structure.

- fonction create_account qui doit créer un compte en banque en remplissant la structure et retourner un pointeur vers celle-ci.

L'argent d'un utilisateur qui vient juste d'être créé est à 0.

une fonction display_account qui affiche des donne du compte.

- une fonction clear_account cette fonction doit free l'instance de la structure.


<!-- CONTACT -->
## Contact

FAYE Sarah - faye_s@etna-alternance.net  
![Sarah](https://auth.etna-alternance.net/api/users/faye_s/photo)





