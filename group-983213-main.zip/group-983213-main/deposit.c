#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "user.h"
#include "account.h"

int deposit(t_user *user, int amount)

{
    
    if (amount > 1)
    {
        // qtyA++;
        return 1;
    }
    else
    {
        printf("Something bad happend ;)");
    }
 
user->_qtyA = user->_qtyA + amount;
printf("\nThe amount of money is :\n");
printf("%d\n", user->_qtyA);
 return 0; 

}


int withdraw(t_user *user, int amount)  
{
    
    if (amount > 1)
    {

        return 0;
    }
    else{
        printf("Something bad happend ;)");
        printf("Please check the amount");
    }
 
 user->_qtyA = user->_qtyA - amount;
printf("\nThe amount of money is :\n");
printf("%d\n", user->_qtyA);
 return 1; 

}

    


