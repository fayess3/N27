#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "user.h"
#include "Account"

int deposit(t_user *user, int amount)

{
    
    if (qtyA < 1)
    {
        // qtyA++;
        return 0;
    }
 
 user._qtyA-> user->_qtyA + qtyA;

 return 1; 

}


int withdraw(t_user *user, int amount);

withdraw()
  
{
    
    if (qtyA < 1)
    {
        // qtyA++;
        return 0;
    }
    else
 
 user._qtyA-> user->_qtyA - qtyA;

 return 1; 

}

    


